# 3D NFT Landing Page Collections.

Hi friends, today i hope we get a great day and this repo is a build Simple Ecommerce with laravel, this app ordering without login customer can check order with unique code. This app has only one user is admin to manage thier products customer can't register and login. Specialy for UI for client i use Atomic Design Structure and for admin UI i use beautiful template from [Mazer](https://github.com/zuramai/mazer). 

Social Media : \
[Instagram](https://www.instagram.com/bedddev/) \
[Dribbble](https://dribbble.com/bedddev) \
[Youtube](https://www.youtube.com/channel/UC_XQkWu_EPqam4vHdvh058A)

hope you guys like it\
Thanks a lot![Thumbnail](https://user-images.githubusercontent.com/78606852/178409940-52907ab3-73df-4d5d-9dec-fa448b39c0d5.png)

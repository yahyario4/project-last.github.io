<ul class="nav-list">
  <li class="nav-item">
    <a href="/" class="nav-link">Home</a>
  </li>
  <li class="nav-item">
    <a href="<?php echo e(route('clientProducts')); ?>" class="nav-link">Produk</a>
  </li>
  <li class="nav-item">
    <a href="<?php echo e(route('clientCategory')); ?>" class="nav-link">Kategori</a>
  </li>
  <li class="nav-item">
    <a href="<?php echo e(route('clientAbout')); ?>" class="nav-link">Tentang</a>
  </li>
  <li class="nav-item">
    <a href="<?php echo e(route('clientCheckOrder')); ?>" class="nav-link">Cek pesanan</a>
  </li>
</ul><?php /**PATH C:\xamp\htdocs\simple-ecommerce-laravel\resources\views/client/components/molecules/navbar/menu.blade.php ENDPATH**/ ?>
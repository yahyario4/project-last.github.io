<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('client/components/molecules/hero/text-block.css')); ?>">
<?php $__env->stopPush(); ?>

<div class="text-center text-block-hero py-5">
    <h1>Produk elektronik</h1>
    <p>Memudahkan kita semua, anda hanya membuka dengan smartphone lalu barang akan datang kerumah anda.</p>
</div><?php /**PATH C:\xamp\htdocs\simple-ecommerce-laravel\resources\views/client/components/molecules/hero/text-block.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title); ?></title>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/iconly/bold.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/perfect-scrollbar/perfect-scrollbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/bootstrap-icons/bootstrap-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/sweetalert2/sweetalert2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/toastify/toastify.css')); ?>">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/images/favicon.svg')); ?>">
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>
    <div id="app">
        <div id="sidebar" class="active">
            <div class="sidebar-wrapper active">
                <div class="sidebar-header">
                    <div class="d-flex justify-content-center">
                        <div class="logo shadow rounded">
                            <a href="<?php echo e(route('home')); ?>">
                                <img src='<?php echo e(asset("shop/".Auth::user()->shop->path."")); ?>' alt="Logo" srcset="" style="height:100px;" class="rounded">
                            </a>
                        </div>
                        <div class="toggler">
                            <a href="<?php echo e(route('home')); ?>" class="sidebar-hide d-xl-none d-block">
                                <i class="bi bi-x bi-middle"></i></a>
                        </div>
                    </div>
                </div>
                <div class="sidebar-menu">
                    <ul class="menu">
                        <li class="sidebar-item <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('home')); ?>" class='sidebar-link'>
                                <i class="bi bi-grid-fill"></i>
                                <span>Dashboard</span>
                            </a>
                        </li>

                        <li class="sidebar-item <?php echo e(request()->routeIs('category') || request()->routeIs('categoryCreate') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('category')); ?>" class='sidebar-link'>
                                <i class="bi bi-stack"></i>
                                <span>Kategori</span>
                            </a>
                        </li>

                        <li class="sidebar-item <?php echo e(request()->routeIs('products') || request()->routeIs('productCreate') || request()->routeIs('productAddImages') || request()->routeIs('productEdit') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('products')); ?>" class='sidebar-link'>
                                <i class="bi bi-box"></i>
                                <span>Produk</span>
                            </a>

                        </li>

                        <li class="sidebar-item <?php echo e(request()->routeIs('orders') || request()->routeIs('orderDetail') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('orders')); ?>" class='sidebar-link'>
                                <i class="bi bi-bag"></i>
                                <span>Pesanan</span>
                            </a>
                        </li>

                        <li class="sidebar-item <?php echo e(request()->routeIs('shopDetail') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('shopDetail')); ?>" class='sidebar-link'>
                                <i class="bi bi-shop"></i>
                                <span>Belanja</span>
                            </a>
                        </li>

                        <li class="sidebar-item has-sub mt-5">
                            <a href="" class='sidebar-link'>
                                <i class="bi bi-person-circle"></i>
                                <span><?php echo e(Auth::user()->name); ?></span>
                            </a>
                            <ul class="submenu ">
                                <li class="submenu-item ">
                                    <a href="#" data-bs-toggle="modal" data-bs-target="#modalUpdatePassword">Change password</a>
                                </li>
                                <li class="submenu-item ">
                                    <a href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">Log Out</a>
                                </li>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </ul>
                        </li>
                    </ul>
                </div>
                <button class="sidebar-toggler btn x"><i data-feather="x"></i></button>
            </div>
        </div>

        <!-- Modal Update Status -->
        <div class="modal fade" id="modalUpdatePassword" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="modalUpdatePasswordLabel" aria-hidden="true">
            <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalUpdatePasswordLabel">Update Password</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('shopUpdatePassword')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group position-relative has-icon-left mb-4">
                            <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password" placeholder="New Password">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="form-control-icon">
                                <i class="bi bi-shield-lock"></i>
                            </div>
                        </div>
                        <div class="form-group position-relative has-icon-left mb-4">
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password" placeholder="New Password Confirmation">
                            <div class="form-control-icon">
                                <i class="bi bi-shield-lock-fill"></i>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary float-end">Save</button>
                    </form>
                </div>
            </div>
            </div>
        </div>

        <div id="main">
            <header class="mb-3">
                <a href="#" class="burger-btn d-block d-xl-none">
                    <i class="bi bi-justify fs-3"></i>
                </a>
            </header>

            <div class=" card">
                <div class="card-body d-flex justify-content-between align-items-center">
                <h3><?php echo e($title); ?></h3>
                <?php echo $__env->yieldContent('button'); ?>
                </div>
            </div>
            <div class="page-content">
                <section class="row">
                    <?php echo $__env->yieldContent('content'); ?>
                </section>
            </div>

            <footer>
                <div class="footer clearfix mb-0 text-muted">
                    <div class="float-start">
                        <p>2023 &copy; Rio</p>
                    </div>
                    <div class="float-end">
                        <p>Dibuat with <span class="text-danger"><i class="bi bi-heart"></i></span> Oleh <a
                                href="https://www.instagram.com/riowahyualyahya/?hl=id">Rio wahyu al yahya</a></p>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <script src="<?php echo e(asset('assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/mazer.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/toastify/toastify.js')); ?>"></script>
    <?php echo $__env->yieldContent('js'); ?>
    <?php if(session('success')): ?>
        <script>
            Toastify({
                text: "<?php echo e(session('success')); ?>",
                duration: 3000,
                close:true,
                gravity:"top",
                position: "right",
                backgroundColor: "#4fbe87",
            }).showToast();
        </script>
    <?php endif; ?>

    <?php if(session('failed')): ?>
        <script>
            Toastify({
                text: "<?php echo e(session('failed')); ?>",
                duration: 3000,
                close:true,
                gravity:"top",
                position: "right",
                backgroundColor: "#f3616d",
            }).showToast();
        </script>
    <?php endif; ?>
</body>

</html>
<?php /**PATH C:\xamp\htdocs\simple-ecommerce-laravel\resources\views/admin/layout.blade.php ENDPATH**/ ?>
<ul class="nav-list">
  <li class="nav-item">
    <a href="/" class="nav-link">Home</a>
  </li>
  <li class="nav-item">
    <a href="{{ route('clientProducts') }}" class="nav-link">Produk</a>
  </li>
  <li class="nav-item">
    <a href="{{ route('clientCategory') }}" class="nav-link">Kategori</a>
  </li>
  <li class="nav-item">
    <a href="{{ route('clientAbout') }}" class="nav-link">Tentang</a>
  </li>
  <li class="nav-item">
    <a href="{{ route('clientCheckOrder') }}" class="nav-link">Cek pesanan</a>
  </li>
</ul>
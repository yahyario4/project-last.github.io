@push('css')
    <link rel="stylesheet" href="{{ asset('client/components/molecules/hero/text-block.css') }}">
@endpush

<div class="text-center text-block-hero py-5">
    <h1>Produk elektronik</h1>
    <p>Memudahkan kita semua, anda hanya membuka dengan smartphone lalu barang akan datang kerumah anda.</p>
</div>
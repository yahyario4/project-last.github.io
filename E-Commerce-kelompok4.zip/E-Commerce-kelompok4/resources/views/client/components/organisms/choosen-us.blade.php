<div class="container py-5">
    <h1 class="text-center py-5">Kenapa Harus Memilih kami</h1>
    <div class="row g-4">
        <div class="col-md-4 col-12">
            <x-molecules.choosen-block icon="bi-box" title="Gratis pengiriman" desc="Gratis pengiriman dibawah 1JT" bg="primary"/>
        </div>        
        <div class="col-md-4 col-6">
            <x-molecules.choosen-block icon="bi-cash" title="Garansi uang kembali" desc="Dalam 30 Hari" bg="info"/>
        </div>
        <div class="col-md-4 col-6">
            <x-molecules.choosen-block icon="bi-clock" title="24/7 Support" desc="Ramah untuk pembeli" bg="success"/>
        </div>
    </div>
</div>